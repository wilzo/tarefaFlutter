// import 'package:firebase_helpers/firebase_helpers.dart';
// import 'package:mercadinho/models/event/event_model.dart';

// DatabaseService<EventModel> eventDBS = DatabaseService<EventModel>("events",
//     fromDS: (id, data) => EventModel.fromDS(id, data),
//     toMap: (event) => {
//       "title":event.title,
//       "description": event.description,
//       "event_date":event.eventDate,
//       "id":event.id,
//     });
